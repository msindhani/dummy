import os
import wget
import sys
import pandas as pd
import docx
import docx2txt
import win32com.client


#DOCX to TXT

def doc2txt(in_dir, out_dir):
 try:
    app = win32com.client.Dispatch('Word.Application')
    app.Visible = False
    for subdir, dirs, files in os.walk(in_dir):
        for file in files:
            fullpath = os.path.join(*[subdir, file])
            if file.endswith(".docx"):
                out_name = file.replace("docx", r"txt")
                in_file = os.path.abspath(in_dir + "\\" + file)
                out_file = os.path.abspath(out_dir + "\\" + out_name)
                doc = app.Documents.Open(in_file)
                content = doc.Content.Text
                doc.SaveAs(out_file, FileFormat=7)
                doc.Close()
 except Exception as e:
    print(e)
 finally:
    app.Quit()


#ppt to pdf


def ppttopdf(path):
 ppttoPDF = 32	
 for root, dirs, files in os.walk(path):
    for f in files:

        if f.endswith(".pptx"):
            try:
                print(f)
                in_file=os.path.join(root,f)
                powerpoint = win32com.client.Dispatch("Powerpoint.Application")
                deck = powerpoint.Presentations.Open(in_file)
                deck.SaveAs(os.path.join(root,f[:-5]), ppttoPDF) # formatType = 32 for ppt to pdf
                deck.Close()
                powerpoint.Quit()
                print('done')
                os.remove(os.path.join(root,f))
                pass
            except:
                print('could not open')
                # os.remove(os.path.join(root,f))
        elif f.endswith(".ppt"):
            try:
                print(f)
                in_file=os.path.join(root,f)
                powerpoint = win32com.client.Dispatch("Powerpoint.Application")
                deck = powerpoint.Presentations.Open(in_file)
                deck.SaveAs(os.path.join(root,f[:-4]), ppttoPDF) # formatType = 32 for ppt to pdf
                deck.Close()
                powerpoint.Quit()
                print('done')
                os.remove(os.path.join(root,f))
                pass
            except:
                print('could not open')
                # os.remove(os.path.join(root,f))
        else:
            pass